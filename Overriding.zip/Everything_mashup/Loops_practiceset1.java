import java.util.*;
public class Loops_practiceset1 {
    public static void main(String args[]){

        int i=0;
        while(i<=10){
            System.out.println(i);
            i++;
       // for(int i=0;i<=10;i++){
       //     System.out.println(i);
        }
        }
       
}
