import java.util.*;
public class Loops1 {
    public static void main(String args[]){
       // for(int i=1;i<=3;i++){
         //   System.out.println("Hello World");
        //}
       // Scanner sc=new Scanner(System.in);
       // int n=5;
        int i=0;
        while (i<5) {
            System.out.println("Hello world");
            i++;
        }
    }
}
