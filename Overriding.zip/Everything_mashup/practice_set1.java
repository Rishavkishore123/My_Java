public class practice_set1 {
    public static void main(String[] args){
        System.out.println("This is the world of coding");
        System.out.println("And You learning the java Coding by Sharadha kapoor");
        

    }
}
