import java.util.*;
public class Average1 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        
        int side=sc.nextInt();
        int area=side*side;
       // int b=sc.nextInt();
        //int c=sc.nextInt();
       // float avg=(a+b+c)/3;
       // System.out.println("The avg value of:"+avg);
       System.out.println("The area of square is:"+area);
    }
}
