class A{
    
    public int method1(){
        return 4;
    }

    public void method2(){
        System.out.println("This is the class of method 2 of class A");
    }
}

class B extends A{
    public void method2(){
        System.out.println("This is the class of method 2 of class B");
    }
    public void method3(){
        System.out.println("Hello Girls, How are you ??");
    }
}

public class practice1{
    public static void main(String[] args){
        A a=new A();
        a.method2();
        B b= new B();
        b.method2();
    }
}
