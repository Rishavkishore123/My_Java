public  class Demo{
    public static void main( String[] args){
        Fruits fruits1= new Fruits("apple",40);
        fruits1.displayInfo();
    }
}